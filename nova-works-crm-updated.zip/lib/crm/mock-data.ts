import type { Project, Task, User } from './types'
import rawData from './novaworks_projects.json'

/** Every seeded demo account signs in with this password. */
export const DEMO_PASSWORD = 'Demo123!'

export const USERS: User[] = [
  {
    id: 'u-admin',
    name: 'Admin User',
    email: 'admin@novaworks.example',
    role: 'ADMIN',
    title: 'Workspace Administrator',
    specialization: 'Operations & Delivery Governance',
    skills: ['Resource Planning', 'Client Intake', 'Reporting', 'Access Control'],
  },
  {
    id: 'u-ayesha',
    name: 'Ayesha Khan',
    email: 'ayesha@novaworks.example',
    role: 'MANAGER',
    title: 'E-commerce Specialist',
    specialization: 'E-commerce & Web Platforms',
    skills: ['Agile / Scrum', 'Stakeholder Management', 'Roadmapping', 'Shopify'],
  },
  {
    id: 'u-bilal',
    name: 'Bilal Ahmed',
    email: 'bilal@novaworks.example',
    role: 'MANAGER',
    title: 'Mobile Development Lead',
    specialization: 'Mobile Development',
    skills: ['Product Discovery', 'Kanban', 'App Store Releases', 'Analytics'],
  },
  {
    id: 'u-hina',
    name: 'Hina Malik',
    email: 'hina@novaworks.example',
    role: 'MANAGER',
    title: 'Cloud & DevOps Lead',
    specialization: 'Cloud & DevOps',
    skills: ['Risk Management', 'Cloud Budgeting', 'Security & Compliance', 'OKRs'],
  },
  {
    id: 'u-ali',
    name: 'Ali Raza',
    email: 'ali@novaworks.example',
    role: 'AGENT',
    title: 'Frontend Developer',
    specialization: 'Frontend Engineering',
    skills: ['React', 'Next.js', 'TypeScript', 'Tailwind CSS'],
  },
  {
    id: 'u-hamza',
    name: 'Hamza Shah',
    email: 'hamza@novaworks.example',
    role: 'AGENT',
    title: 'Backend Developer',
    specialization: 'APIs & Databases',
    skills: ['Node.js', 'PostgreSQL', 'REST', 'GraphQL'],
  },
  {
    id: 'u-sara',
    name: 'Sara Noor',
    email: 'sara@novaworks.example',
    role: 'AGENT',
    title: 'UI/UX Designer',
    specialization: 'UI / UX Design',
    skills: ['Figma', 'Design Systems', 'Prototyping', 'User Research'],
  },
  {
    id: 'u-usman',
    name: 'Usman Tariq',
    email: 'usman@novaworks.example',
    role: 'AGENT',
    title: 'QA Engineer',
    specialization: 'Quality Assurance & Testing',
    skills: ['Unit Testing', 'Jest', 'Cypress', 'Test Automation'],
  },
  {
    id: 'u-zain',
    name: 'Zain Abbas',
    email: 'zain@novaworks.example',
    role: 'AGENT',
    title: 'Mobile Developer',
    specialization: 'Cross-platform Mobile',
    skills: ['Flutter', 'Dart', 'iOS', 'Android'],
  },
  {
    id: 'u-maryam',
    name: 'Maryam Asif',
    email: 'maryam@novaworks.example',
    role: 'AGENT',
    title: 'DevOps Engineer',
    specialization: 'Cloud Infrastructure & CI/CD',
    skills: ['AWS', 'Docker', 'Terraform', 'GitHub Actions'],
  },
]

/* -------------------------------------------------------------------------- */
/*  Projects & tasks are built from novaworks_projects.json (AI-parsed        */
/*  transcript). manager_email / agent_email are resolved to real users here. */
/* -------------------------------------------------------------------------- */

const userByEmail = new Map(USERS.map((u) => [u.email.toLowerCase(), u]))

function resolveUser(email: string, expectedRole: 'MANAGER' | 'AGENT', context: string): User {
  const user = userByEmail.get(email.toLowerCase())
  if (!user) {
    throw new Error(`novaworks_projects.json: no user with email "${email}" (${context})`)
  }
  if (user.role !== expectedRole) {
    throw new Error(
      `novaworks_projects.json: "${email}" is a ${user.role}, expected ${expectedRole} (${context})`,
    )
  }
  return user
}

const slug = (s: string) =>
  s
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-|-$/g, '')

export const PROJECTS: Project[] = rawData.projects.map((p) => {
  const projectId = `p-${slug(p.client_name)}`
  const manager = resolveUser(p.manager_email, 'MANAGER', `manager of "${p.name}"`)

  const tasks: Task[] = p.tasks.map((t, i) => {
    const agent = resolveUser(t.agent_email, 'AGENT', `assignee of "${t.title}"`)
    return {
      id: `t-${slug(p.client_name)}-${i + 1}`,
      title: t.title,
      description: t.description,
      assigneeId: agent.id,
      estimatedHours: t.estimated_hours,
      deadline: t.deadline,
      status: 'todo',
    }
  })

  const hours = tasks.reduce((sum, t) => sum + t.estimatedHours, 0)

  return {
    id: projectId,
    name: p.name,
    clientName: p.client_name,
    managerId: manager.id,
    deadline: p.deadline,
    summary: `${p.client_name} engagement: ${tasks.length} tasks, ${hours}h estimated. Scoped by AI from the client intake call.`,
    tasks,
    createdFromTranscript: true,
  }
})

export const SAMPLE_TRANSCRIPT = `Project: Clinic Booking Platform
Client: Shifa Medical Group
Deadline: 2026-12-20

Call notes — kickoff with Dr. Farah and ops team.
They need patients to book appointments online and receive reminders.

- Design patient booking flow and doctor schedule screens (16h)
- Build Next.js booking web app with calendar UI (24h)
- Appointments API and PostgreSQL schema (20h)
- React Native companion app for reminders (18h)
- Set up AWS hosting and CI/CD pipeline (10h)
- Unit testing for booking and reminder flows (12h)`
