/**
 * Mock data layer. Each function mirrors the contract of a future backend endpoint,
 * so swapping to real calls only requires replacing the function bodies:
 *
 *   login(email, password)  -> POST /api/login       { email, password } => User
 *   getProjects()           -> GET  /api/projects                     => Project[]
 *   processTranscript(text) -> POST /api/transcript  { transcript }  => Project
 */
import { DEMO_PASSWORD, PROJECTS, USERS } from './mock-data'
import type { Project, Task, User } from './types'

const wait = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms))

export async function login(email: string, password: string = DEMO_PASSWORD): Promise<User> {
  // const res = await fetch('/api/login', { method: 'POST', body: JSON.stringify({ email, password }) })
  await wait(250)
  const user = USERS.find((u) => u.email.toLowerCase() === email.trim().toLowerCase())
  if (!user || password !== DEMO_PASSWORD) throw new Error('Invalid email or password')
  return user
}

export async function getProjects(): Promise<Project[]> {
  // const res = await fetch('/api/projects', { cache: 'no-store' })
  return PROJECTS
}

export async function getUsers(): Promise<User[]> {
  return USERS
}

// Order matters: the first agent whose keywords match wins, so more specific roles come first.
const SKILL_KEYWORDS: Record<string, string[]> = {
  'u-sara': ['design', 'figma', 'mockup', 'wireframe', 'ux', 'screens', 'prototype'],
  'u-zain': ['react native', 'mobile', 'ios', 'android', 'flutter', 'app store', 'companion app'],
  'u-usman': ['unit test', 'testing', 'qa', 'quality', 'regression', 'e2e', 'bug'],
  'u-maryam': ['aws', 'ci/cd', 'hosting', 'docker', 'deploy', 'infrastructure', 'terraform', 'kubernetes', 'pipeline'],
  'u-hamza': ['api', 'backend', 'postgres', 'database', 'schema', 'endpoint', 'python', 'report', 'data'],
  'u-ali': ['next.js', 'react', 'frontend', 'web app', 'dashboard', 'calendar', 'page'],
}

const MANAGER_KEYWORDS: Record<string, string[]> = {
  'u-ayesha': ['e-commerce', 'ecommerce', 'storefront', 'checkout', 'web app', 'web platform', 'next.js'],
  'u-bilal': ['mobile', 'ios', 'android', 'flutter', 'react native', 'app store'],
  'u-hina': ['cloud', 'aws', 'devops', 'docker', 'ci/cd', 'infrastructure', 'migrat'],
}

function pickAssignee(text: string, index: number): string {
  const lower = ` ${text.toLowerCase()} `
  const match = Object.entries(SKILL_KEYWORDS).find(([, keywords]) =>
    keywords.some((k) => lower.includes(k)),
  )
  if (match) return match[0]
  const agents = USERS.filter((u) => u.role === 'AGENT')
  return agents[index % agents.length].id
}

function pickManager(text: string, existingProjects: Project[]): string {
  const lower = text.toLowerCase()
  const managers = USERS.filter((u) => u.role === 'MANAGER')
  return managers
    .map((m) => ({
      id: m.id,
      score: (MANAGER_KEYWORDS[m.id] ?? []).filter((k) => lower.includes(k)).length,
      load: existingProjects.filter((p) => p.managerId === m.id).length,
    }))
    .sort((a, b) => b.score - a.score || a.load - b.load)[0].id
}

function addDays(days: number): string {
  const d = new Date()
  d.setDate(d.getDate() + days)
  return d.toISOString().slice(0, 10)
}

export async function processTranscript(
  transcript: string,
  existingProjects: Project[],
): Promise<Project> {
  // const res = await fetch('/api/transcript', { method: 'POST', body: JSON.stringify({ transcript }) })
  await wait(1800)

  const field = (label: string) =>
    transcript.match(new RegExp(`^\\s*${label}\\s*[:\\-]\\s*(.+)$`, 'im'))?.[1]?.trim()

  const name = field('project') ?? 'Untitled Transcript Project'
  const clientName = field('client') ?? 'Unspecified Client'
  const parsedDeadline = field('deadline')
  const deadline =
    parsedDeadline && !Number.isNaN(Date.parse(parsedDeadline)) ? parsedDeadline : addDays(45)

  const bulletLines = transcript
    .split('\n')
    .map((l) => l.trim())
    .filter((l) => /^([-*•]|\d+[.)])\s+/.test(l))
    .map((l) => l.replace(/^([-*•]|\d+[.)])\s+/, ''))

  const sourceLines = bulletLines.length
    ? bulletLines
    : ['Discovery & requirements workshop', 'Implement core features', 'QA and release']

  const managerId = pickManager(transcript, existingProjects)

  const stamp = Date.now()
  const tasks: Task[] = sourceLines.map((line, i) => {
    const hours = Number(line.match(/\((\d+)\s*h(?:ours?)?\)/i)?.[1] ?? 8)
    const title = line.replace(/\(\d+\s*h(?:ours?)?\)/i, '').trim()
    return {
      id: `t-${stamp}-${i}`,
      title,
      description: `Generated from transcript: "${title}".`,
      assigneeId: pickAssignee(title, i),
      estimatedHours: hours,
      deadline: addDays(10 + i * 5),
      status: 'todo',
    }
  })

  return {
    id: `p-${stamp}`,
    name,
    clientName,
    managerId,
    deadline,
    summary: `Created from a ${transcript.split(/\s+/).length}-word transcript.`,
    tasks,
    createdFromTranscript: true,
  }
}
