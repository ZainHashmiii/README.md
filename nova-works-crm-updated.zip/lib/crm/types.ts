export type Role = 'ADMIN' | 'MANAGER' | 'AGENT'

export interface User {
  id: string
  name: string
  email: string
  role: Role
  title: string
  specialization: string
  skills: string[]
}

export type TaskStatus = 'todo' | 'done'

export interface Task {
  id: string
  title: string
  description: string
  assigneeId: string
  estimatedHours: number
  deadline: string
  status: TaskStatus
}

export interface Project {
  id: string
  name: string
  clientName: string
  managerId: string
  deadline: string
  summary: string
  tasks: Task[]
  createdFromTranscript?: boolean
}

export interface AgentTask extends Task {
  projectId: string
  projectName: string
  clientName: string
}
