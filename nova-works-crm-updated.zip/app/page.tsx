import { CrmApp } from '@/components/crm/crm-app'
import { getProjects, getUsers } from '@/lib/crm/api'

export default async function Page() {
  const [projects, users] = await Promise.all([getProjects(), getUsers()])
  return <CrmApp initialProjects={projects} users={users} />
}
