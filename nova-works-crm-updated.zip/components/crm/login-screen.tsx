'use client'

import { useState } from 'react'
import { ArrowRight, Loader2 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Initials, RoleBadge } from './badges'
import type { User } from '@/lib/crm/types'

interface LoginScreenProps {
  users: User[]
  pendingEmail: string | null
  error?: string | null
  onLogin: (email: string, password?: string) => void
}

export function LoginScreen({ users, pendingEmail, error, onLogin }: LoginScreenProps) {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    onLogin(email, password)
  }

  const inputClass =
    'h-9 w-full rounded-md border border-border bg-background px-3 text-sm focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none disabled:opacity-60'

  return (
    <section className="mx-auto max-w-4xl py-10 md:py-16" aria-labelledby="login-heading">
      <p className="font-mono text-xs font-semibold tracking-wider text-brand uppercase">
        Internal workspace
      </p>
      <h1 id="login-heading" className="mt-2 text-3xl font-semibold tracking-tight text-balance md:text-4xl">
        Sign in to NovaWorks CRM
      </h1>
      <p className="mt-3 max-w-xl leading-relaxed text-muted-foreground">
        Pick a seeded demo account to explore the Admin, Manager, or Agent experience. Each role
        sees only the projects and tasks it is permitted to view.
      </p>


      <form
        onSubmit={handleSubmit}
        className="mt-8 flex max-w-xl flex-col gap-3 rounded-xl border border-border bg-card p-4"
        aria-label="Sign in with email and password"
      >
        <div className="grid gap-3 sm:grid-cols-2">
          <label className="flex flex-col gap-1.5 text-xs font-medium text-muted-foreground">
            Email
            <input
              type="email"
              required
              autoComplete="username"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="ayesha@novaworks.example"
              disabled={pendingEmail !== null}
              className={inputClass}
            />
          </label>
          <label className="flex flex-col gap-1.5 text-xs font-medium text-muted-foreground">
            Password
            <input
              type="password"
              required
              autoComplete="current-password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Demo123!"
              disabled={pendingEmail !== null}
              className={inputClass}
            />
          </label>
        </div>
        <div className="flex items-center justify-between gap-3">
          <p className="text-xs text-muted-foreground" aria-live="polite">
            {error ? (
              <span className="text-destructive">{error}</span>
            ) : (
              <>
                All demo accounts use password <code className="font-mono text-foreground">Demo123!</code>
              </>
            )}
          </p>
          <Button
            type="submit"
            disabled={pendingEmail !== null}
            className="bg-brand text-brand-foreground hover:bg-brand/90"
          >
            Sign in
          </Button>
        </div>
      </form>

      <p className="mt-8 font-mono text-[11px] font-semibold tracking-wider text-muted-foreground uppercase">
        Or pick a demo account
      </p>
      <ul className="mt-3 grid gap-2 sm:grid-cols-2">
        {users.map((u) => (
          <li key={u.id}>
            <button
              type="button"
              onClick={() => onLogin(u.email)}
              disabled={pendingEmail !== null}
              className="group flex w-full items-center gap-3 rounded-lg border border-border bg-card p-3 text-left transition-colors hover:border-brand/50 focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none disabled:opacity-60"
            >
              <Initials name={u.name} />
              <span className="min-w-0 flex-1">
                <span className="flex items-center gap-2">
                  <span className="truncate text-sm font-medium">{u.name}</span>
                  <RoleBadge role={u.role} />
                </span>
                <span className="block truncate font-mono text-xs text-muted-foreground">
                  {u.email}
                </span>
              </span>
              {pendingEmail === u.email ? (
                <Loader2 className="size-4 animate-spin text-brand" aria-label="Signing in" />
              ) : (
                <ArrowRight
                  className="size-4 text-muted-foreground transition-transform group-hover:translate-x-0.5 group-hover:text-brand"
                  aria-hidden="true"
                />
              )}
            </button>
          </li>
        ))}
      </ul>
    </section>
  )
}
