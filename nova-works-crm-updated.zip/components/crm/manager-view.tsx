import { FolderOpen } from 'lucide-react'
import { ProjectCard } from './project-card'
import { StatRow, ViewHeader } from './stat-row'
import type { Project, User } from '@/lib/crm/types'

interface ManagerViewProps {
  manager: User
  projects: Project[]
  usersById: Map<string, User>
}

export function ManagerView({ manager, projects, usersById }: ManagerViewProps) {
  const tasks = projects.flatMap((p) => p.tasks)
  const openTasks = tasks.filter((t) => t.status !== 'done').length
  const hours = tasks.reduce((sum, t) => sum + t.estimatedHours, 0)
  const agents = new Set(tasks.map((t) => t.assigneeId)).size

  return (
    <div className="flex flex-col gap-8">
      <ViewHeader
        eyebrow={`Manager · ${manager.specialization}`}
        title="My Managed Projects"
        description={`Projects where ${manager.name} is the accountable manager, with task assignments and estimates.`}
      />

      <StatRow
        stats={[
          { label: 'My projects', value: projects.length },
          { label: 'Open tasks', value: openTasks },
          { label: 'Agents involved', value: agents },
          { label: 'Estimated hours', value: `${hours}h` },
        ]}
      />

      {projects.length === 0 ? (
        <div className="flex flex-col items-center gap-2 rounded-xl border border-dashed border-border px-6 py-14 text-center">
          <FolderOpen className="size-6 text-muted-foreground" aria-hidden="true" />
          <p className="font-medium">No managed projects yet</p>
          <p className="text-sm text-muted-foreground">
            New projects assigned to you by an admin will appear here.
          </p>
        </div>
      ) : (
        <div className="grid gap-4 lg:grid-cols-2">
          {projects.map((project) => (
            <ProjectCard key={project.id} project={project} usersById={usersById} variant="detailed" />
          ))}
        </div>
      )}
    </div>
  )
}
