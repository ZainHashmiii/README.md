'use client'

import { FolderKanban, ListChecks } from 'lucide-react'
import { Checkbox } from '@/components/ui/checkbox'
import { cn } from '@/lib/utils'
import { formatDate } from '@/lib/crm/format'
import { DeadlineBadge, HoursBadge } from './badges'
import { StatRow, ViewHeader } from './stat-row'
import type { AgentTask, User } from '@/lib/crm/types'

interface AgentViewProps {
  agent: User
  tasks: AgentTask[]
  onToggleTask: (projectId: string, taskId: string, done: boolean) => void
}

export function AgentView({ agent, tasks, onToggleTask }: AgentViewProps) {
  const sorted = [...tasks].sort((a, b) => {
    if (a.status !== b.status) return a.status === 'done' ? 1 : -1
    return a.deadline.localeCompare(b.deadline)
  })
  const open = tasks.filter((t) => t.status !== 'done')
  const remainingHours = open.reduce((sum, t) => sum + t.estimatedHours, 0)
  const nextDeadline = open.map((t) => t.deadline).sort()[0]

  return (
    <div className="flex flex-col gap-8">
      <ViewHeader
        eyebrow={`Agent · ${agent.specialization}`}
        title="My Assigned Tasks"
        description="Everything assigned to you across NovaWorks projects, ordered by deadline."
      />

      <StatRow
        stats={[
          { label: 'Open tasks', value: open.length },
          { label: 'Completed', value: tasks.length - open.length },
          { label: 'Hours remaining', value: `${remainingHours}h` },
          { label: 'Next deadline', value: nextDeadline ? formatDate(nextDeadline).replace(/, \d{4}$/, '') : '—' },
        ]}
      />

      {sorted.length === 0 ? (
        <div className="flex flex-col items-center gap-2 rounded-xl border border-dashed border-border px-6 py-14 text-center">
          <ListChecks className="size-6 text-muted-foreground" aria-hidden="true" />
          <p className="font-medium">{"You're all caught up"}</p>
          <p className="text-sm text-muted-foreground">No tasks are currently assigned to you.</p>
        </div>
      ) : (
        <ul className="flex flex-col gap-3" aria-label="Assigned tasks">
          {sorted.map((task) => {
            const isDone = task.status === 'done'
            const checkboxId = `task-${task.id}`
            return (
              <li
                key={task.id}
                className={cn(
                  'flex gap-4 rounded-xl border border-border bg-card p-4 transition-opacity',
                  isDone && 'opacity-60',
                )}
              >
                <Checkbox
                  id={checkboxId}
                  checked={isDone}
                  onCheckedChange={(checked) => onToggleTask(task.projectId, task.id, checked === true)}
                  className="mt-0.5"
                  aria-label={`Mark "${task.title}" as ${isDone ? 'not done' : 'done'}`}
                />
                <div className="flex min-w-0 flex-1 flex-col gap-2 md:flex-row md:items-start md:justify-between md:gap-6">
                  <div className="min-w-0">
                    <label
                      htmlFor={checkboxId}
                      className={cn('cursor-pointer font-medium', isDone && 'line-through')}
                    >
                      {task.title}
                    </label>
                    <p className="mt-1 text-sm leading-relaxed text-muted-foreground">{task.description}</p>
                    <p className="mt-2 flex items-center gap-1.5 text-xs text-muted-foreground">
                      <FolderKanban className="size-3.5" aria-hidden="true" />
                      <span className="font-medium text-foreground">{task.projectName}</span>
                      <span aria-hidden="true">·</span>
                      <span>{task.clientName}</span>
                    </p>
                  </div>
                  <div className="flex shrink-0 flex-wrap items-center gap-1.5 md:justify-end">
                    <DeadlineBadge date={task.deadline} />
                    <HoursBadge hours={task.estimatedHours} />
                  </div>
                </div>
              </li>
            )
          })}
        </ul>
      )}
    </div>
  )
}
