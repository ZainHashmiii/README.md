'use client'

import { useState } from 'react'
import { CheckCircle2, FileText, Loader2, Sparkles } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { SAMPLE_TRANSCRIPT } from '@/lib/crm/mock-data'
import type { Project } from '@/lib/crm/types'

interface TranscriptPanelProps {
  onProcess: (transcript: string) => Promise<Project>
}

export function TranscriptPanel({ onProcess }: TranscriptPanelProps) {
  const [transcript, setTranscript] = useState('')
  const [isProcessing, setIsProcessing] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [created, setCreated] = useState<Project | null>(null)

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    if (!transcript.trim()) {
      setError('Paste a transcript before processing.')
      return
    }
    setError(null)
    setCreated(null)
    setIsProcessing(true)
    try {
      const project = await onProcess(transcript)
      setCreated(project)
      setTranscript('')
    } catch {
      setError('Something went wrong while processing the transcript. Please try again.')
    } finally {
      setIsProcessing(false)
    }
  }

  const wordCount = transcript.trim() ? transcript.trim().split(/\s+/).length : 0

  return (
    <section
      aria-labelledby="transcript-heading"
      className="overflow-hidden rounded-xl border border-brand/30 bg-card"
    >
      <div className="flex flex-col gap-1 border-b border-border bg-brand/5 px-5 py-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-3">
          <span className="flex size-9 items-center justify-center rounded-lg bg-brand/15 text-brand">
            <Sparkles className="size-4.5" aria-hidden="true" />
          </span>
          <div>
            <h2 id="transcript-heading" className="font-semibold">
              Create Projects from Transcript
            </h2>
            <p className="text-sm text-muted-foreground">
              Paste a client call transcript. AI extracts the project, tasks, estimates and
              assigns the best-fit team members.
            </p>
          </div>
        </div>
        <Button
          type="button"
          variant="ghost"
          size="sm"
          onClick={() => setTranscript(SAMPLE_TRANSCRIPT)}
          disabled={isProcessing}
          className="self-start sm:self-auto"
        >
          <FileText aria-hidden="true" />
          Load sample
        </Button>
      </div>

      <form onSubmit={handleSubmit} className="flex flex-col gap-3 p-5">
        <label htmlFor="transcript" className="sr-only">
          Meeting transcript
        </label>
        <Textarea
          id="transcript"
          value={transcript}
          onChange={(e) => setTranscript(e.target.value)}
          placeholder={'Project: ...\nClient: ...\n\n- Task description (8h)\n- Another task (12h)'}
          disabled={isProcessing}
          aria-invalid={Boolean(error)}
          aria-describedby="transcript-help"
          className="min-h-56 resize-y font-mono text-sm leading-relaxed"
        />
        <div className="flex flex-col-reverse gap-3 sm:flex-row sm:items-center sm:justify-between">
          <p id="transcript-help" className="text-xs text-muted-foreground" aria-live="polite">
            {error ? (
              <span className="text-destructive">{error}</span>
            ) : (
              <>
                <span className="font-mono">{wordCount}</span> words · Tip: include{' '}
                <code className="font-mono text-foreground">Project:</code> and{' '}
                <code className="font-mono text-foreground">Client:</code> lines
              </>
            )}
          </p>
          <Button
            type="submit"
            size="lg"
            disabled={isProcessing}
            className="bg-brand text-brand-foreground hover:bg-brand/90"
          >
            {isProcessing ? (
              <>
                <Loader2 className="animate-spin" aria-hidden="true" />
                Processing transcript…
              </>
            ) : (
              <>
                <Sparkles aria-hidden="true" />
                Process Transcript with AI
              </>
            )}
          </Button>
        </div>

        {created && (
          <div
            role="status"
            className="flex items-start gap-2.5 rounded-lg border border-brand/30 bg-brand/10 px-3 py-2.5 text-sm"
          >
            <CheckCircle2 className="mt-0.5 size-4 shrink-0 text-brand" aria-hidden="true" />
            <p>
              Created <span className="font-semibold">{created.name}</span> for{' '}
              {created.clientName} with {created.tasks.length} tasks. It now appears first in the
              grid below.
            </p>
          </div>
        )}
      </form>
    </section>
  )
}
