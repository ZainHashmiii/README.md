'use client'

import { useState } from 'react'
import { Hexagon, LogOut, Moon, Sun, Users } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Initials, RoleBadge } from './badges'
import type { User } from '@/lib/crm/types'

interface CrmNavbarProps {
  user: User | null
  onLogout: () => void
  onOpenDirectory: () => void
}

export function CrmNavbar({ user, onLogout, onOpenDirectory }: CrmNavbarProps) {
  const [isDark, setIsDark] = useState(true)

  function toggleTheme() {
    const next = !isDark
    setIsDark(next)
    document.documentElement.classList.toggle('dark', next)
    document.documentElement.classList.toggle('light', !next)
  }

  return (
    <div className="flex h-14 items-center gap-3 px-4 md:px-6">
      <a href="#" className="flex items-center gap-2" aria-label="NovaWorks CRM home">
        <span className="flex size-8 items-center justify-center rounded-lg bg-brand text-brand-foreground">
          <Hexagon className="size-4.5" aria-hidden="true" />
        </span>
        <span className="text-sm font-semibold tracking-tight md:text-base">
          NovaWorks <span className="text-muted-foreground">CRM</span>
        </span>
      </a>

      <div className="ml-auto flex items-center gap-1.5 md:gap-2">
        <Button variant="ghost" size="sm" onClick={onOpenDirectory}>
          <Users aria-hidden="true" />
          <span className="hidden sm:inline">Team Directory</span>
          <span className="sr-only sm:hidden">Open team directory</span>
        </Button>
        <Button
          variant="ghost"
          size="icon-sm"
          onClick={toggleTheme}
          aria-label={isDark ? 'Switch to light theme' : 'Switch to dark theme'}
        >
          {isDark ? <Sun aria-hidden="true" /> : <Moon aria-hidden="true" />}
        </Button>

        {user && (
          <>
            <div className="mx-1 hidden h-6 w-px bg-border sm:block" aria-hidden="true" />
            <div className="flex items-center gap-2.5">
              <Initials name={user.name} className="hidden sm:inline-flex" />
              <div className="flex flex-col leading-tight">
                <span className="text-sm font-medium">{user.name}</span>
                <RoleBadge role={user.role} className="mt-0.5 self-start" />
              </div>
            </div>
            <Button variant="outline" size="sm" onClick={onLogout} className="ml-1">
              <LogOut aria-hidden="true" />
              <span className="hidden sm:inline">Logout</span>
              <span className="sr-only sm:hidden">Logout</span>
            </Button>
          </>
        )}
      </div>
    </div>
  )
}
