'use client'

import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle } from '@/components/ui/sheet'
import { Initials, RoleBadge } from './badges'
import type { Role, User } from '@/lib/crm/types'

interface TeamDirectoryProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  users: User[]
}

const ORDER: Role[] = ['ADMIN', 'MANAGER', 'AGENT']
const LABELS: Record<Role, string> = { ADMIN: 'Administration', MANAGER: 'Managers', AGENT: 'Agents' }

export function TeamDirectory({ open, onOpenChange, users }: TeamDirectoryProps) {
  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent side="right" className="w-full gap-0 sm:max-w-md">
        <SheetHeader className="border-b border-border">
          <SheetTitle>Team Directory</SheetTitle>
          <SheetDescription>
            {users.length} members · read-only view of roles, specializations and skills.
          </SheetDescription>
        </SheetHeader>
        <div className="flex-1 overflow-y-auto px-4 py-4">
          {ORDER.map((role) => {
            const members = users.filter((u) => u.role === role)
            return (
              <section key={role} className="mb-6 last:mb-0" aria-labelledby={`dir-${role}`}>
                <h3
                  id={`dir-${role}`}
                  className="mb-2 font-mono text-[11px] font-semibold tracking-wider text-muted-foreground uppercase"
                >
                  {LABELS[role]} <span className="text-foreground">{members.length}</span>
                </h3>
                <ul className="flex flex-col gap-2">
                  {members.map((u) => (
                    <li key={u.id} className="rounded-lg border border-border bg-card p-3">
                      <div className="flex items-start gap-3">
                        <Initials name={u.name} className="size-9" />
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center justify-between gap-2">
                            <p className="truncate text-sm font-medium">{u.name}</p>
                            <RoleBadge role={u.role} />
                          </div>
                          <p className="text-xs text-muted-foreground">{u.title}</p>
                          <p className="truncate font-mono text-xs text-muted-foreground">{u.email}</p>
                        </div>
                      </div>
                      <p className="mt-3 text-xs">
                        <span className="text-muted-foreground">Specialization </span>
                        <span className="font-medium">{u.specialization}</span>
                      </p>
                      <ul className="mt-2 flex flex-wrap gap-1" aria-label={`${u.name} skills`}>
                        {u.skills.map((skill) => (
                          <li
                            key={skill}
                            className="rounded-md border border-border bg-muted px-1.5 py-0.5 text-[11px] text-muted-foreground"
                          >
                            {skill}
                          </li>
                        ))}
                      </ul>
                    </li>
                  ))}
                </ul>
              </section>
            )
          })}
        </div>
      </SheetContent>
    </Sheet>
  )
}
