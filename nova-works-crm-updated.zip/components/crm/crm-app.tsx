'use client'

import { useMemo, useState } from 'react'
import { login, processTranscript } from '@/lib/crm/api'
import type { AgentTask, Project, User } from '@/lib/crm/types'
import { AdminView } from './admin-view'
import { AgentView } from './agent-view'
import { CrmNavbar } from './crm-navbar'
import { DemoAccountBar } from './demo-account-bar'
import { LoginScreen } from './login-screen'
import { ManagerView } from './manager-view'
import { TeamDirectory } from './team-directory'

interface CrmAppProps {
  initialProjects: Project[]
  users: User[]
}

export function CrmApp({ initialProjects, users }: CrmAppProps) {
  const [currentUser, setCurrentUser] = useState<User | null>(null)
  const [projects, setProjects] = useState<Project[]>(initialProjects)
  const [pendingEmail, setPendingEmail] = useState<string | null>(null)
  const [loginError, setLoginError] = useState<string | null>(null)
  const [isDirectoryOpen, setIsDirectoryOpen] = useState(false)
  const [highlightedProjectId, setHighlightedProjectId] = useState<string | null>(null)

  const usersById = useMemo(() => new Map(users.map((u) => [u.id, u])), [users])

  // Demo buttons call handleLogin(email) and use the shared demo password;
  // the sign-in form passes whatever password the user typed.
  async function handleLogin(email: string, password?: string) {
    setPendingEmail(email)
    setLoginError(null)
    try {
      const user = await login(email, password)
      setCurrentUser(user)
      setHighlightedProjectId(null)
    } catch (err) {
      setLoginError(err instanceof Error ? err.message : 'Unable to sign in')
    } finally {
      setPendingEmail(null)
    }
  }

  async function handleProcessTranscript(transcript: string) {
    const project = await processTranscript(transcript, projects)
    setProjects((prev) => [project, ...prev])
    setHighlightedProjectId(project.id)
    return project
  }

  function handleToggleTask(projectId: string, taskId: string, done: boolean) {
    setProjects((prev) =>
      prev.map((p) =>
        p.id !== projectId
          ? p
          : {
              ...p,
              tasks: p.tasks.map((t) => (t.id === taskId ? { ...t, status: done ? 'done' : 'todo' } : t)),
            },
      ),
    )
  }

  const managedProjects = useMemo(
    () => (currentUser ? projects.filter((p) => p.managerId === currentUser.id) : []),
    [projects, currentUser],
  )

  const agentTasks = useMemo<AgentTask[]>(
    () =>
      currentUser
        ? projects.flatMap((p) =>
            p.tasks
              .filter((t) => t.assigneeId === currentUser.id)
              .map((t) => ({ ...t, projectId: p.id, projectName: p.name, clientName: p.clientName })),
          )
        : [],
    [projects, currentUser],
  )

  return (
    <div className="min-h-dvh bg-background">
      <header className="sticky top-0 z-40 border-b border-border bg-background/85 backdrop-blur-md">
        <CrmNavbar
          user={currentUser}
          onLogout={() => setCurrentUser(null)}
          onOpenDirectory={() => setIsDirectoryOpen(true)}
        />
        <DemoAccountBar
          users={users}
          activeUserId={currentUser?.id ?? null}
          pendingEmail={pendingEmail}
          onLogin={handleLogin}
        />
      </header>

      <main className="mx-auto w-full max-w-7xl px-4 py-8 md:px-6 md:py-10">
        {!currentUser && (
          <LoginScreen
            users={users}
            pendingEmail={pendingEmail}
            error={loginError}
            onLogin={handleLogin}
          />
        )}
        {currentUser?.role === 'ADMIN' && (
          <AdminView
            projects={projects}
            usersById={usersById}
            highlightedProjectId={highlightedProjectId}
            onProcessTranscript={handleProcessTranscript}
          />
        )}
        {currentUser?.role === 'MANAGER' && (
          <ManagerView manager={currentUser} projects={managedProjects} usersById={usersById} />
        )}
        {currentUser?.role === 'AGENT' && (
          <AgentView agent={currentUser} tasks={agentTasks} onToggleTask={handleToggleTask} />
        )}
      </main>

      <TeamDirectory open={isDirectoryOpen} onOpenChange={setIsDirectoryOpen} users={users} />
    </div>
  )
}
