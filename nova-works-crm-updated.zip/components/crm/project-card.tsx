import { Building2, CheckCircle2, Circle, Sparkles } from 'lucide-react'
import { cn } from '@/lib/utils'
import { formatDate } from '@/lib/crm/format'
import { DeadlineBadge, HoursBadge, Initials } from './badges'
import type { Project, User } from '@/lib/crm/types'

interface ProjectCardProps {
  project: Project
  usersById: Map<string, User>
  variant?: 'summary' | 'detailed'
  highlight?: boolean
}

export function ProjectCard({ project, usersById, variant = 'summary', highlight }: ProjectCardProps) {
  const manager = usersById.get(project.managerId)
  const done = project.tasks.filter((t) => t.status === 'done').length
  const total = project.tasks.length
  const hours = project.tasks.reduce((sum, t) => sum + t.estimatedHours, 0)
  const progress = total ? Math.round((done / total) * 100) : 0
  const assignees = [...new Set(project.tasks.map((t) => t.assigneeId))]
    .map((id) => usersById.get(id))
    .filter((u): u is User => Boolean(u))

  return (
    <article
      className={cn(
        'flex flex-col rounded-xl border bg-card text-card-foreground transition-colors',
        highlight ? 'border-brand/60 ring-1 ring-brand/30' : 'border-border',
      )}
      aria-labelledby={`project-${project.id}`}
    >
      <header className="flex flex-col gap-3 p-4 pb-3">
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <h3 id={`project-${project.id}`} className="font-semibold leading-snug text-pretty">
              {project.name}
            </h3>
            <p className="mt-1 flex items-center gap-1.5 text-sm text-muted-foreground">
              <Building2 className="size-3.5 shrink-0" aria-hidden="true" />
              <span className="truncate">{project.clientName}</span>
            </p>
          </div>
          {project.createdFromTranscript && (
            <span className="inline-flex h-5 shrink-0 items-center gap-1 rounded-md bg-brand/15 px-1.5 text-[10px] font-semibold tracking-wide text-brand uppercase">
              <Sparkles className="size-3" aria-hidden="true" />
              AI
            </span>
          )}
        </div>
        <div className="flex flex-wrap items-center gap-1.5">
          <DeadlineBadge date={project.deadline} />
          <HoursBadge hours={hours} />
        </div>
      </header>

      {variant === 'summary' ? (
        <div className="mt-auto flex flex-col gap-3 border-t border-border p-4">
          <p className="text-sm leading-relaxed text-muted-foreground line-clamp-2">{project.summary}</p>
          <div>
            <div className="mb-1.5 flex items-center justify-between text-xs">
              <span className="text-muted-foreground">
                {done}/{total} tasks complete
              </span>
              <span className="font-mono">{progress}%</span>
            </div>
            <div
              className="h-1.5 overflow-hidden rounded-full bg-muted"
              role="progressbar"
              aria-valuenow={progress}
              aria-valuemin={0}
              aria-valuemax={100}
              aria-label={`${project.name} progress`}
            >
              <div className="h-full rounded-full bg-brand" style={{ width: `${progress}%` }} />
            </div>
          </div>
          <div className="flex items-center justify-between gap-2">
            <span className="text-xs text-muted-foreground">
              Manager <span className="font-medium text-foreground">{manager?.name ?? '—'}</span>
            </span>
            <div className="flex -space-x-2" aria-label={`Assigned: ${assignees.map((a) => a.name).join(', ')}`}>
              {assignees.slice(0, 4).map((a) => (
                <Initials key={a.id} name={a.name} className="size-6 border-2 border-card text-[9px]" />
              ))}
            </div>
          </div>
        </div>
      ) : (
        <div className="border-t border-border">
          <div className="flex items-center justify-between px-4 pt-3 pb-1">
            <h4 className="text-xs font-medium tracking-wide text-muted-foreground uppercase">Tasks</h4>
            <span className="font-mono text-xs text-muted-foreground">
              {done}/{total} done
            </span>
          </div>
          {total === 0 ? (
            <p className="px-4 pb-4 text-sm text-muted-foreground">No tasks yet.</p>
          ) : (
            <ul className="divide-y divide-border">
              {project.tasks.map((task) => {
                const agent = usersById.get(task.assigneeId)
                const isDone = task.status === 'done'
                return (
                  <li key={task.id} className="flex items-start gap-3 px-4 py-3">
                    {isDone ? (
                      <CheckCircle2 className="mt-0.5 size-4 shrink-0 text-brand" aria-label="Done" />
                    ) : (
                      <Circle className="mt-0.5 size-4 shrink-0 text-muted-foreground" aria-label="Open" />
                    )}
                    <div className="min-w-0 flex-1">
                      <p className={cn('text-sm font-medium', isDone && 'text-muted-foreground line-through')}>
                        {task.title}
                      </p>
                      <div className="mt-1.5 flex flex-wrap items-center gap-x-3 gap-y-1.5 text-xs text-muted-foreground">
                        <span className="flex items-center gap-1.5">
                          <Initials name={agent?.name ?? '?'} className="size-5 text-[8px]" />
                          <span className="text-foreground">{agent?.name ?? 'Unassigned'}</span>
                        </span>
                        <span>Due {formatDate(task.deadline)}</span>
                      </div>
                    </div>
                    <HoursBadge hours={task.estimatedHours} />
                  </li>
                )
              })}
            </ul>
          )}
        </div>
      )}
    </article>
  )
}
