'use client'

import { ProjectCard } from './project-card'
import { StatRow, ViewHeader } from './stat-row'
import { TranscriptPanel } from './transcript-panel'
import type { Project, User } from '@/lib/crm/types'

interface AdminViewProps {
  projects: Project[]
  usersById: Map<string, User>
  highlightedProjectId: string | null
  onProcessTranscript: (transcript: string) => Promise<Project>
}

export function AdminView({
  projects,
  usersById,
  highlightedProjectId,
  onProcessTranscript,
}: AdminViewProps) {
  const tasks = projects.flatMap((p) => p.tasks)
  const openTasks = tasks.filter((t) => t.status !== 'done').length
  const hours = tasks.reduce((sum, t) => sum + t.estimatedHours, 0)
  const clients = new Set(projects.map((p) => p.clientName)).size

  return (
    <div className="flex flex-col gap-8">
      <ViewHeader
        eyebrow="Admin console"
        title="NovaWorks Portfolio"
        description="Turn client conversations into scoped projects and oversee every engagement across the agency."
      />

      <TranscriptPanel onProcess={onProcessTranscript} />

      <StatRow
        stats={[
          { label: 'Active projects', value: projects.length },
          { label: 'Clients', value: clients },
          { label: 'Open tasks', value: openTasks },
          { label: 'Estimated hours', value: `${hours}h` },
        ]}
      />

      <section aria-labelledby="all-projects-heading" className="flex flex-col gap-4">
        <div className="flex items-baseline justify-between">
          <h2 id="all-projects-heading" className="text-lg font-semibold">
            All Projects
          </h2>
          <span className="font-mono text-xs text-muted-foreground">{projects.length} total</span>
        </div>
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {projects.map((project) => (
            <ProjectCard
              key={project.id}
              project={project}
              usersById={usersById}
              highlight={project.id === highlightedProjectId}
            />
          ))}
        </div>
      </section>
    </div>
  )
}
