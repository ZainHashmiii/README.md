'use client'

import { Loader2 } from 'lucide-react'
import { cn } from '@/lib/utils'
import type { Role, User } from '@/lib/crm/types'

interface DemoAccountBarProps {
  users: User[]
  activeUserId: string | null
  pendingEmail: string | null
  onLogin: (email: string) => void
}

const GROUPS: { role: Role; label: string }[] = [
  { role: 'ADMIN', label: 'Admin' },
  { role: 'MANAGER', label: 'Managers' },
  { role: 'AGENT', label: 'Agents' },
]

export function DemoAccountBar({ users, activeUserId, pendingEmail, onLogin }: DemoAccountBarProps) {
  return (
    <div className="border-t border-border bg-muted/40">
      <div
        className="flex items-center gap-4 overflow-x-auto px-4 py-2 md:px-6"
        role="toolbar"
        aria-label="Demo login switcher"
      >
        <span className="shrink-0 font-mono text-[11px] font-semibold tracking-wider text-brand uppercase">
          Demo login
        </span>
        {GROUPS.map((group) => (
          <div key={group.role} className="flex shrink-0 items-center gap-1.5">
            <span className="text-xs text-muted-foreground">{group.label}</span>
            {users
              .filter((u) => u.role === group.role)
              .map((u) => {
                const isActive = u.id === activeUserId
                const isPending = u.email === pendingEmail
                return (
                  <button
                    key={u.id}
                    type="button"
                    onClick={() => onLogin(u.email)}
                    disabled={isPending}
                    aria-pressed={isActive}
                    title={u.email}
                    className={cn(
                      'inline-flex h-7 items-center gap-1.5 rounded-md border px-2.5 text-xs font-medium whitespace-nowrap transition-colors focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none',
                      isActive
                        ? 'border-brand bg-brand text-brand-foreground'
                        : 'border-border bg-background text-foreground hover:border-brand/50 hover:bg-brand/10',
                    )}
                  >
                    {isPending && <Loader2 className="size-3 animate-spin" aria-hidden="true" />}
                    {u.name.split(' ')[0]}
                  </button>
                )
              })}
          </div>
        ))}
      </div>
    </div>
  )
}
