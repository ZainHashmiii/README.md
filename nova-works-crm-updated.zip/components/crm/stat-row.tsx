export interface Stat {
  label: string
  value: string | number
}

export function StatRow({ stats }: { stats: Stat[] }) {
  return (
    <dl className="grid grid-cols-2 overflow-hidden rounded-xl border border-border bg-border md:grid-cols-4 gap-px">
      {stats.map((s) => (
        <div key={s.label} className="bg-card px-4 py-3">
          <dt className="text-xs text-muted-foreground">{s.label}</dt>
          <dd className="mt-1 font-mono text-xl font-semibold tracking-tight">{s.value}</dd>
        </div>
      ))}
    </dl>
  )
}

export function ViewHeader({
  eyebrow,
  title,
  description,
}: {
  eyebrow: string
  title: string
  description: string
}) {
  return (
    <div>
      <p className="font-mono text-xs font-semibold tracking-wider text-brand uppercase">{eyebrow}</p>
      <h1 className="mt-1.5 text-2xl font-semibold tracking-tight text-balance md:text-3xl">{title}</h1>
      <p className="mt-1.5 text-sm leading-relaxed text-muted-foreground">{description}</p>
    </div>
  )
}
