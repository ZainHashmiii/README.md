import { CalendarClock, Clock } from 'lucide-react'
import { cn } from '@/lib/utils'
import { daysUntil, formatDate, initials } from '@/lib/crm/format'
import type { Role } from '@/lib/crm/types'

const ROLE_STYLES: Record<Role, string> = {
  ADMIN: 'bg-brand text-brand-foreground border-transparent',
  MANAGER: 'border-brand/40 bg-brand/10 text-brand',
  AGENT: 'border-border bg-secondary text-secondary-foreground',
}

export function RoleBadge({ role, className }: { role: Role; className?: string }) {
  return (
    <span
      className={cn(
        'inline-flex h-5 items-center rounded-md border px-1.5 font-mono text-[10px] font-semibold tracking-wider',
        ROLE_STYLES[role],
        className,
      )}
    >
      {role}
    </span>
  )
}

export function DeadlineBadge({ date, className }: { date: string; className?: string }) {
  const days = daysUntil(date)
  const tone =
    days < 0
      ? 'border-destructive/40 bg-destructive/10 text-destructive'
      : days <= 7
        ? 'border-warning/40 bg-warning/10 text-warning'
        : 'border-border bg-muted text-muted-foreground'
  const hint = days < 0 ? `${Math.abs(days)}d overdue` : days === 0 ? 'Today' : `${days}d left`

  return (
    <span
      className={cn(
        'inline-flex h-6 items-center gap-1.5 rounded-md border px-2 text-xs font-medium whitespace-nowrap',
        tone,
        className,
      )}
    >
      <CalendarClock className="size-3.5" aria-hidden="true" />
      <span>{formatDate(date)}</span>
      <span className="opacity-70">{'· '}{hint}</span>
    </span>
  )
}

export function HoursBadge({ hours, className }: { hours: number; className?: string }) {
  return (
    <span
      className={cn(
        'inline-flex h-6 items-center gap-1 rounded-md border border-border bg-background px-2 font-mono text-xs text-foreground whitespace-nowrap',
        className,
      )}
    >
      <Clock className="size-3.5 text-muted-foreground" aria-hidden="true" />
      {hours}h
      <span className="sr-only">estimated</span>
    </span>
  )
}

export function Initials({
  name,
  className,
}: {
  name: string
  className?: string
}) {
  return (
    <span
      aria-hidden="true"
      className={cn(
        'inline-flex size-8 shrink-0 items-center justify-center rounded-full border border-border bg-secondary text-xs font-semibold text-secondary-foreground',
        className,
      )}
    >
      {initials(name)}
    </span>
  )
}
